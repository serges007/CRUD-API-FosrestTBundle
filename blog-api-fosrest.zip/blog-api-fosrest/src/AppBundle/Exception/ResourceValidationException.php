<?php

namespace AppBundle\Exception;

class ResourceValidationException extends \Exception
{
}